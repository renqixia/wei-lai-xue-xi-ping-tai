/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from 'react';
import { AppProvider, useAppContext } from './context/AppContext';
import { Dashboard } from './components/Dashboard';
import { Learn } from './components/Learn';
import { Quiz } from './components/Quiz';
import { Settings } from './components/Settings';
import { Navigation } from './components/Navigation';

const AppContent: React.FC = () => {
  const { currentView, bgColor, theme } = useAppContext();

  const renderView = () => {
    switch (currentView) {
      case 'dashboard': return <Dashboard />;
      case 'learn': return <Learn />;
      case 'quiz': return <Quiz />;
      case 'settings': return <Settings />;
      default: return <Dashboard />;
    }
  };

  return (
    <div className={`min-h-screen pb-24 transition-colors duration-300 ${theme === 'dark' ? 'bg-gray-900' : bgColor}`}>
      <main className="pt-8">
        {renderView()}
      </main>
      <Navigation />
    </div>
  );
};

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
