import React, { useState, useEffect, useRef } from 'react';
import { useAppContext } from '../context/AppContext';
import { vocabularyData, Word } from '../data/vocabulary';
import { Volume2, ArrowLeft, Loader2 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { fetchTTSAudio, getAudioContext } from '../services/tts';
import { WaveformVisualizer } from './WaveformVisualizer';

export const Learn: React.FC = () => {
  const { selectedCategory, wordStats, reviewWord, setCurrentView } = useAppContext();
  const [words, setWords] = useState<Word[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  
  const [isPlaying, setIsPlaying] = useState(false);
  const [isLoadingAudio, setIsLoadingAudio] = useState(false);
  const [analyser, setAnalyser] = useState<AnalyserNode | null>(null);
  const sourceRef = useRef<AudioBufferSourceNode | null>(null);

  useEffect(() => {
    const now = Date.now();
    const categoryWords = vocabularyData.filter(w => w.category === selectedCategory);
    
    // 1. Words due for review
    const dueWords = categoryWords.filter(w => wordStats[w.id] && wordStats[w.id].nextReviewDate <= now);
    
    // 2. New words
    const newWords = categoryWords.filter(w => !wordStats[w.id]);

    // Combine them (reviews first, then new words)
    const queue = [...dueWords, ...newWords].slice(0, 20); // Limit session to 20 words

    if (queue.length === 0) {
      // If nothing is due, just show some random learned words for practice
      setWords(categoryWords.sort(() => 0.5 - Math.random()).slice(0, 10));
    } else {
      setWords(queue);
    }
    setCurrentIndex(0);
    setIsFlipped(false);
  }, [selectedCategory, wordStats]);

  const stopAudio = () => {
    if (sourceRef.current) {
      try { sourceRef.current.stop(); } catch (e) {}
      sourceRef.current = null;
    }
    setIsPlaying(false);
  };

  useEffect(() => {
    return () => stopAudio();
  }, []);

  const playDetailedAudio = async (word: string) => {
    if (isPlaying || isLoadingAudio) return;
    setIsLoadingAudio(true);
    try {
      const prompt = `Act as an encouraging English teacher. Say the word "${word}" clearly. Then break it down into syllables and pronounce each syllable slowly. Then say the word again with a warm, human-like tone.`;
      const audioBuffer = await fetchTTSAudio(prompt);
      
      const ctx = getAudioContext();
      const source = ctx.createBufferSource();
      source.buffer = audioBuffer;
      
      const newAnalyser = ctx.createAnalyser();
      source.connect(newAnalyser);
      newAnalyser.connect(ctx.destination);
      
      setAnalyser(newAnalyser);
      sourceRef.current = source;
      
      source.onended = () => setIsPlaying(false);
      source.start();
      setIsPlaying(true);
    } catch (error) {
      console.error(error);
      // Fallback to standard TTS if Gemini fails
      const utterance = new SpeechSynthesisUtterance(word);
      window.speechSynthesis.speak(utterance);
    } finally {
      setIsLoadingAudio(false);
    }
  };

  const playExampleAudio = async (example: string) => {
    if (isPlaying || isLoadingAudio) return;
    setIsLoadingAudio(true);
    try {
      const prompt = `Read this example sentence naturally and expressively: "${example}"`;
      const audioBuffer = await fetchTTSAudio(prompt);
      
      const ctx = getAudioContext();
      const source = ctx.createBufferSource();
      source.buffer = audioBuffer;
      
      const newAnalyser = ctx.createAnalyser();
      source.connect(newAnalyser);
      newAnalyser.connect(ctx.destination);
      
      setAnalyser(newAnalyser);
      sourceRef.current = source;
      
      source.onended = () => setIsPlaying(false);
      source.start();
      setIsPlaying(true);
    } catch (error) {
      console.error(error);
      const utterance = new SpeechSynthesisUtterance(example);
      window.speechSynthesis.speak(utterance);
    } finally {
      setIsLoadingAudio(false);
    }
  };

  const handleReview = (quality: number) => {
    stopAudio();
    if (words[currentIndex]) {
      reviewWord(words[currentIndex].id, quality);
    }
    if (currentIndex < words.length - 1) {
      setIsFlipped(false);
      setCurrentIndex(prev => prev + 1);
    } else {
      setCurrentView('dashboard');
    }
  };

  if (words.length === 0) {
    return <div className="text-center p-10 dark:text-white">Loading...</div>;
  }

  const currentWord = words[currentIndex];

  return (
    <div className="max-w-2xl mx-auto p-6 flex flex-col items-center justify-center min-h-[70vh]">
      <div className="w-full flex justify-between items-center mb-6 text-gray-500 dark:text-gray-400">
        <span>{currentIndex + 1} / {words.length}</span>
        <span className="bg-gray-200 dark:bg-gray-700 px-3 py-1 rounded-full text-sm font-medium">
          {selectedCategory}
        </span>
      </div>

      <div className="relative w-full h-96 perspective-1000">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentWord.id + (isFlipped ? '-flipped' : '')}
            initial={{ rotateY: isFlipped ? -90 : 90, opacity: 0 }}
            animate={{ rotateY: 0, opacity: 1 }}
            exit={{ rotateY: isFlipped ? 90 : -90, opacity: 0 }}
            transition={{ duration: 0.3 }}
            className="absolute inset-0 w-full h-full cursor-pointer"
            onClick={() => {
              if (!isPlaying && !isLoadingAudio) {
                setIsFlipped(!isFlipped);
              }
            }}
          >
            {/* Front of Card */}
            <div className={`w-full h-full bg-white dark:bg-gray-800 rounded-3xl shadow-lg border border-gray-100 dark:border-gray-700 flex flex-col items-center justify-center p-8 text-center ${isFlipped ? 'hidden' : 'flex'}`}>
              <h2 className="text-5xl font-bold text-gray-900 dark:text-white mb-4">{currentWord.word}</h2>
              <p className="text-xl text-gray-500 dark:text-gray-400 font-mono mb-6">{currentWord.phonetic}</p>
              
              <div className="h-20 mb-4 flex items-center justify-center w-full">
                <WaveformVisualizer analyser={analyser} isPlaying={isPlaying && !isFlipped} />
              </div>

              <button 
                onClick={(e) => { e.stopPropagation(); playDetailedAudio(currentWord.word); }}
                disabled={isLoadingAudio || isPlaying}
                className="p-4 bg-blue-50 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-full hover:bg-blue-100 dark:hover:bg-blue-900/50 transition-colors disabled:opacity-50"
                title="AI Detailed Pronunciation"
              >
                {isLoadingAudio ? <Loader2 className="w-8 h-8 animate-spin" /> : <Volume2 className="w-8 h-8" />}
              </button>
              
              <p className="mt-6 text-sm text-gray-400 dark:text-gray-500 uppercase tracking-widest">Tap to flip</p>
            </div>

            {/* Back of Card */}
            <div className={`w-full h-full bg-white dark:bg-gray-800 rounded-3xl shadow-lg border border-gray-100 dark:border-gray-700 flex flex-col items-center justify-center p-8 text-center ${!isFlipped ? 'hidden' : 'flex'}`}>
              <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-6">{currentWord.translation}</h2>
              
              <div className="w-full max-w-md bg-gray-50 dark:bg-gray-700/50 p-6 rounded-2xl flex flex-col items-center">
                <p className="text-lg text-gray-700 dark:text-gray-300 italic mb-4">"{currentWord.example}"</p>
                
                <div className="h-12 mb-2 flex items-center justify-center w-full">
                  <WaveformVisualizer analyser={analyser} isPlaying={isPlaying && isFlipped} />
                </div>

                <button 
                  onClick={(e) => { e.stopPropagation(); playExampleAudio(currentWord.example); }}
                  disabled={isLoadingAudio || isPlaying}
                  className="text-blue-500 hover:text-blue-600 dark:text-blue-400 flex items-center gap-2 mx-auto text-sm font-medium disabled:opacity-50"
                >
                  {isLoadingAudio ? <Loader2 className="w-4 h-4 animate-spin" /> : <Volume2 className="w-4 h-4" />} 
                  Listen to example
                </button>
              </div>
            </div>
          </motion.div>
        </AnimatePresence>
      </div>

      <div className="flex items-center justify-between w-full mt-10">
        <button 
          onClick={() => {
            if (currentIndex > 0) {
              stopAudio();
              setIsFlipped(false);
              setCurrentIndex(prev => prev - 1);
            }
          }}
          disabled={currentIndex === 0}
          className="p-4 rounded-full bg-gray-200 dark:bg-gray-700 text-gray-600 dark:text-gray-300 disabled:opacity-50 hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors"
        >
          <ArrowLeft className="w-6 h-6" />
        </button>
        
        {isFlipped ? (
          <div className="flex gap-2">
            <button onClick={() => handleReview(1)} className="px-4 py-2 bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-300 rounded-xl font-medium hover:bg-red-200 dark:hover:bg-red-900/60">Again</button>
            <button onClick={() => handleReview(3)} className="px-4 py-2 bg-orange-100 text-orange-700 dark:bg-orange-900/40 dark:text-orange-300 rounded-xl font-medium hover:bg-orange-200 dark:hover:bg-orange-900/60">Hard</button>
            <button onClick={() => handleReview(4)} className="px-4 py-2 bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-300 rounded-xl font-medium hover:bg-blue-200 dark:hover:bg-blue-900/60">Good</button>
            <button onClick={() => handleReview(5)} className="px-4 py-2 bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-300 rounded-xl font-medium hover:bg-green-200 dark:hover:bg-green-900/60">Easy</button>
          </div>
        ) : (
          <div className="text-sm text-gray-400 dark:text-gray-500">Flip to rate</div>
        )}
      </div>
    </div>
  );
};
