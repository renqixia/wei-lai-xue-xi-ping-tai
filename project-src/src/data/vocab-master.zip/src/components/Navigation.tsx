import React from 'react';
import { useAppContext } from '../context/AppContext';
import { Home, BookOpen, BrainCircuit, Settings as SettingsIcon } from 'lucide-react';

export const Navigation: React.FC = () => {
  const { currentView, setCurrentView } = useAppContext();

  const navItems = [
    { id: 'dashboard', icon: Home, label: 'Home' },
    { id: 'learn', icon: BookOpen, label: 'Learn' },
    { id: 'quiz', icon: BrainCircuit, label: 'Quiz' },
    { id: 'settings', icon: SettingsIcon, label: 'Settings' },
  ] as const;

  return (
    <nav className="fixed bottom-0 left-0 w-full bg-white dark:bg-gray-900 border-t border-gray-200 dark:border-gray-800 pb-safe z-50">
      <div className="max-w-md mx-auto px-6 h-20 flex items-center justify-between">
        {navItems.map(({ id, icon: Icon, label }) => {
          const isActive = currentView === id;
          return (
            <button
              key={id}
              onClick={() => setCurrentView(id as any)}
              className={`flex flex-col items-center justify-center w-16 h-full gap-1 transition-colors ${
                isActive 
                  ? 'text-blue-600 dark:text-blue-400' 
                  : 'text-gray-500 dark:text-gray-400 hover:text-gray-900 dark:hover:text-gray-100'
              }`}
            >
              <Icon className={`w-6 h-6 ${isActive ? 'fill-current opacity-20' : ''}`} />
              <span className="text-[10px] font-medium uppercase tracking-wider">{label}</span>
            </button>
          );
        })}
      </div>
    </nav>
  );
};
