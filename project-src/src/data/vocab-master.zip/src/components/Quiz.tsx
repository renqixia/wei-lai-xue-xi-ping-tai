import React, { useState, useEffect, useMemo } from 'react';
import { useAppContext } from '../context/AppContext';
import { vocabularyData, Word } from '../data/vocabulary';
import { Volume2, AlertCircle, CheckCircle2, ArrowRight } from 'lucide-react';
import { motion } from 'motion/react';
import { fetchTTSAudio, getAudioContext } from '../services/tts';

type QuizType = 'word-to-meaning' | 'meaning-to-word' | 'audio-to-word';

interface Question {
  type: QuizType;
  word: Word;
  options: string[];
  correctAnswer: string;
}

export const Quiz: React.FC = () => {
  const { selectedCategory, setCurrentView, reviewWord } = useAppContext();
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<string | null>(null);
  const [score, setScore] = useState(0);
  const [isFinished, setIsFinished] = useState(false);

  // Generate quiz questions
  useEffect(() => {
    const categoryWords = vocabularyData.filter(w => w.category === selectedCategory);
    if (categoryWords.length < 4) return; // Need at least 4 words for options

    // Shuffle and pick 10 words (or less if not enough)
    const shuffledWords = [...categoryWords].sort(() => 0.5 - Math.random()).slice(0, 10);
    
    const generatedQuestions: Question[] = shuffledWords.map(word => {
      const types: QuizType[] = ['word-to-meaning', 'meaning-to-word', 'audio-to-word'];
      const type = types[Math.floor(Math.random() * types.length)];
      
      let correctAnswer = '';
      let optionsPool: string[] = [];

      if (type === 'word-to-meaning') {
        correctAnswer = word.translation;
        optionsPool = categoryWords.map(w => w.translation).filter(t => t !== correctAnswer);
      } else {
        correctAnswer = word.word;
        optionsPool = categoryWords.map(w => w.word).filter(w => w !== correctAnswer);
      }

      // Pick 3 random wrong options
      const wrongOptions = [...optionsPool].sort(() => 0.5 - Math.random()).slice(0, 3);
      const options = [...wrongOptions, correctAnswer].sort(() => 0.5 - Math.random());

      return { type, word, options, correctAnswer };
    });

    setQuestions(generatedQuestions);
  }, [selectedCategory]);

  const playAudio = async (text: string) => {
    try {
      const prompt = `Say the word clearly and naturally: "${text}"`;
      const audioBuffer = await fetchTTSAudio(prompt);
      const ctx = getAudioContext();
      const source = ctx.createBufferSource();
      source.buffer = audioBuffer;
      source.connect(ctx.destination);
      source.start();
    } catch (error) {
      console.error(error);
      if ('speechSynthesis' in window) {
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.lang = 'en-US';
        window.speechSynthesis.speak(utterance);
      }
    }
  };

  // Auto-play audio for audio questions
  useEffect(() => {
    if (questions.length > 0 && !isFinished && questions[currentIndex].type === 'audio-to-word' && !selectedAnswer) {
      playAudio(questions[currentIndex].word.word);
    }
  }, [currentIndex, questions, isFinished, selectedAnswer]);

  const handleAnswer = (answer: string) => {
    if (selectedAnswer) return; // Prevent multiple clicks
    setSelectedAnswer(answer);
    
    const isCorrect = answer === questions[currentIndex].correctAnswer;
    if (isCorrect) {
      setScore(s => s + 1);
      reviewWord(questions[currentIndex].word.id, 4); // Good
    } else {
      reviewWord(questions[currentIndex].word.id, 2); // Hard/Incorrect
    }
  };

  const handleNext = () => {
    if (currentIndex < questions.length - 1) {
      setSelectedAnswer(null);
      setCurrentIndex(prev => prev + 1);
    } else {
      setIsFinished(true);
    }
  };

  if (questions.length === 0) {
    return <div className="text-center p-10 dark:text-white">Not enough words in this category to generate a quiz.</div>;
  }

  if (isFinished) {
    return (
      <div className="max-w-md mx-auto p-8 bg-white dark:bg-gray-800 rounded-3xl shadow-lg text-center mt-10">
        <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">Quiz Complete!</h2>
        <div className="text-6xl font-bold text-orange-500 mb-6">
          {score} / {questions.length}
        </div>
        <p className="text-gray-600 dark:text-gray-400 mb-8">
          {score === questions.length ? 'Perfect score! Outstanding!' : 'Good job! Keep practicing.'}
        </p>
        <button 
          onClick={() => setCurrentView('dashboard')}
          className="w-full py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-semibold transition-colors"
        >
          Back to Dashboard
        </button>
      </div>
    );
  }

  const currentQ = questions[currentIndex];

  return (
    <div className="max-w-2xl mx-auto p-6">
      <div className="flex justify-between items-center mb-8">
        <span className="text-sm font-medium text-gray-500 dark:text-gray-400">
          Question {currentIndex + 1} of {questions.length}
        </span>
        <span className="text-sm font-medium text-orange-500">
          Score: {score}
        </span>
      </div>

      <div className="bg-white dark:bg-gray-800 rounded-3xl p-8 shadow-sm border border-gray-100 dark:border-gray-700 mb-8 min-h-[200px] flex flex-col items-center justify-center text-center">
        {currentQ.type === 'word-to-meaning' && (
          <>
            <p className="text-sm text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-4">What does this mean?</p>
            <h2 className="text-4xl font-bold text-gray-900 dark:text-white">{currentQ.word.word}</h2>
            <button onClick={() => playAudio(currentQ.word.word)} className="mt-4 text-blue-500">
              <Volume2 className="w-6 h-6" />
            </button>
          </>
        )}
        
        {currentQ.type === 'meaning-to-word' && (
          <>
            <p className="text-sm text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-4">Which word means:</p>
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white">{currentQ.word.translation}</h2>
          </>
        )}

        {currentQ.type === 'audio-to-word' && (
          <>
            <p className="text-sm text-gray-500 dark:text-gray-400 uppercase tracking-wider mb-4">Listen and choose</p>
            <button 
              onClick={() => playAudio(currentQ.word.word)} 
              className="p-6 bg-blue-100 dark:bg-blue-900/40 text-blue-600 dark:text-blue-400 rounded-full hover:bg-blue-200 dark:hover:bg-blue-900/60 transition-colors"
            >
              <Volume2 className="w-12 h-12" />
            </button>
          </>
        )}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {currentQ.options.map((option, idx) => {
          let btnClass = "p-6 rounded-2xl text-lg font-medium transition-all duration-200 border-2 ";
          
          if (!selectedAnswer) {
            btnClass += "bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700 hover:border-blue-500 dark:hover:border-blue-500 text-gray-800 dark:text-gray-200";
          } else if (option === currentQ.correctAnswer) {
            btnClass += "bg-green-100 dark:bg-green-900/30 border-green-500 text-green-800 dark:text-green-300";
          } else if (option === selectedAnswer) {
            btnClass += "bg-red-100 dark:bg-red-900/30 border-red-500 text-red-800 dark:text-red-300";
          } else {
            btnClass += "bg-white dark:bg-gray-800 border-gray-200 dark:border-gray-700 text-gray-400 dark:text-gray-600 opacity-50";
          }

          return (
            <button
              key={idx}
              onClick={() => handleAnswer(option)}
              disabled={!!selectedAnswer}
              className={btnClass}
            >
              {option}
            </button>
          );
        })}
      </div>

      {selectedAnswer && (
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mt-8 flex justify-end"
        >
          <button 
            onClick={handleNext}
            className="flex items-center gap-2 px-8 py-4 bg-gray-900 dark:bg-white text-white dark:text-gray-900 rounded-full font-semibold hover:bg-gray-800 dark:hover:bg-gray-100 transition-colors"
          >
            {currentIndex < questions.length - 1 ? 'Next Question' : 'Finish Quiz'} <ArrowRight className="w-5 h-5" />
          </button>
        </motion.div>
      )}
    </div>
  );
};
