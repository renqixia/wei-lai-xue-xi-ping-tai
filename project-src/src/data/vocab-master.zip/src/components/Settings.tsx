import React from 'react';
import { useAppContext } from '../context/AppContext';
import { WordCategory } from '../data/vocabulary';
import { Moon, Sun, Target, BookA, Palette } from 'lucide-react';

export const Settings: React.FC = () => {
  const { 
    theme, setTheme, 
    dailyGoal, setDailyGoal, 
    selectedCategory, setSelectedCategory,
    bgColor, setBgColor
  } = useAppContext();

  const categories: WordCategory[] = ['KET', 'PET', 'Essential'];
  const bgColors = [
    { name: 'Default', class: 'bg-gray-50' },
    { name: 'Warm', class: 'bg-orange-50' },
    { name: 'Cool', class: 'bg-blue-50' },
    { name: 'Nature', class: 'bg-green-50' },
  ];

  return (
    <div className="max-w-2xl mx-auto p-6 space-y-8">
      <h1 className="text-3xl font-bold text-gray-900 dark:text-white mb-8">Settings</h1>

      <div className="bg-white dark:bg-gray-800 rounded-3xl p-6 shadow-sm border border-gray-100 dark:border-gray-700 space-y-8">
        
        {/* Vocabulary Category */}
        <div>
          <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200 flex items-center gap-2 mb-4">
            <BookA className="w-5 h-5 text-blue-500" />
            Vocabulary Level
          </h3>
          <div className="grid grid-cols-3 gap-3">
            {categories.map(cat => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`py-3 px-4 rounded-xl font-medium transition-colors ${
                  selectedCategory === cat 
                    ? 'bg-blue-600 text-white' 
                    : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>

        <hr className="border-gray-100 dark:border-gray-700" />

        {/* Daily Goal */}
        <div>
          <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200 flex items-center gap-2 mb-4">
            <Target className="w-5 h-5 text-orange-500" />
            Daily Goal (Words)
          </h3>
          <div className="flex items-center gap-4">
            <input 
              type="range" 
              min="5" 
              max="100" 
              step="5"
              value={dailyGoal}
              onChange={(e) => setDailyGoal(Number(e.target.value))}
              className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-700 accent-orange-500"
            />
            <span className="text-xl font-bold text-gray-900 dark:text-white w-12 text-center">
              {dailyGoal}
            </span>
          </div>
        </div>

        <hr className="border-gray-100 dark:border-gray-700" />

        {/* Theme */}
        <div>
          <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200 flex items-center gap-2 mb-4">
            {theme === 'dark' ? <Moon className="w-5 h-5 text-purple-500" /> : <Sun className="w-5 h-5 text-yellow-500" />}
            Appearance
          </h3>
          <div className="flex gap-4">
            <button
              onClick={() => setTheme('light')}
              className={`flex-1 py-3 px-4 rounded-xl font-medium flex items-center justify-center gap-2 transition-colors ${
                theme === 'light' 
                  ? 'bg-gray-900 text-white' 
                  : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300'
              }`}
            >
              <Sun className="w-4 h-4" /> Light
            </button>
            <button
              onClick={() => setTheme('dark')}
              className={`flex-1 py-3 px-4 rounded-xl font-medium flex items-center justify-center gap-2 transition-colors ${
                theme === 'dark' 
                  ? 'bg-blue-600 text-white' 
                  : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300'
              }`}
            >
              <Moon className="w-4 h-4" /> Dark
            </button>
          </div>
        </div>

        <hr className="border-gray-100 dark:border-gray-700" />

        {/* Background Color (Light mode only) */}
        <div className={theme === 'dark' ? 'opacity-50 pointer-events-none' : ''}>
          <h3 className="text-lg font-semibold text-gray-800 dark:text-gray-200 flex items-center gap-2 mb-4">
            <Palette className="w-5 h-5 text-pink-500" />
            Background Tint (Light Mode)
          </h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {bgColors.map(color => (
              <button
                key={color.name}
                onClick={() => setBgColor(color.class)}
                className={`py-3 px-4 rounded-xl font-medium transition-all border-2 ${color.class} ${
                  bgColor === color.class 
                    ? 'border-blue-500 text-blue-800' 
                    : 'border-transparent text-gray-700 hover:border-gray-300'
                }`}
              >
                {color.name}
              </button>
            ))}
          </div>
        </div>

      </div>
    </div>
  );
};
